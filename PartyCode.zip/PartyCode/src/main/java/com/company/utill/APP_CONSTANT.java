package com.company.utill;

public class APP_CONSTANT {
	
	  //개발
	
	public static final String uploadPath = "C:/Users/Administrator/Desktop/course/upload/"; 
    public static final String uploadpath = "C:/DEV/upload/";
    public static final String adminUploadPath = "C:/DEV/upload/admin/";
	
}
