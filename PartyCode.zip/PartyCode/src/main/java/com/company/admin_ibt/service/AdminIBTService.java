package com.company.admin_ibt.service;

import java.util.ArrayList;

import com.company.command.IboughtthisVO;

public interface AdminIBTService {
	
	public ArrayList<IboughtthisVO> reservList(int uno);	//���ฮ��Ʈ
}
