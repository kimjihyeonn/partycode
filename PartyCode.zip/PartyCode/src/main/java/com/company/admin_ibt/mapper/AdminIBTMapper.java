package com.company.admin_ibt.mapper;

import java.util.ArrayList;

import com.company.command.IboughtthisVO;

public interface AdminIBTMapper {

	public ArrayList<IboughtthisVO> reservList(int uno);	//���ฮ��Ʈ
}
