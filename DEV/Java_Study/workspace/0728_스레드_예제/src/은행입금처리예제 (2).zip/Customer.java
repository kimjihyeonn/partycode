package �����Ա�ó������;

public class Customer extends Account {
	
	private int money;
	private int inputMoney;
	public Customer(String account) {
		super(account);
		money=20000;
		inputMoney=5000;
		
	}
    @Override
    public void run() {
    	 for(int i=1; i<=10;i++) {
    		 money=money+inputMoney;
    		 System.out.println(getName() +"��"+money+"����");
    		 try {sleep(1000);
    		 
    		 }catch(InterruptedException e) {
    			 System.out.println(e.toString());
    		 }
    	 }
    	 }
	
}
    

