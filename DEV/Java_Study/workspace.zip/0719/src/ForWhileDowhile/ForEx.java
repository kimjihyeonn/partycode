package ForWhileDowhile;

public class ForEx {

	public static void main(String[] args) {
		int i;
		int sum =0;
		for(i=1; i<=100;i++)
		{ sum +=i; // sum=sum+i
		
	}
	
	System.out.println("1���� 100������ ��" + sum);

	}

}
