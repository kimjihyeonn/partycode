package ��ӿ���;

import java.util.Scanner;

public class Helloworld {

	public static void main(String[] args) {
	
		}
	     
  
	}


