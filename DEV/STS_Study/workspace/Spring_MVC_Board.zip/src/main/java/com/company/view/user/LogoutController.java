package com.company.view.user;

public class LogoutController {

}
