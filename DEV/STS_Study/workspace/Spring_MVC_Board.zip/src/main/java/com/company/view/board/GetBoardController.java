package com.company.view.board;

public class GetBoardController {

}
