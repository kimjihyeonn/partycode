package com.company.view.board;

public class UpdateBoardController {

}
