package ���;

public class myCar extends Car {

	public static void main(String[] args) {
		

	}

}
