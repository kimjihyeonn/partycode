
public class TypeConvertEx {

	public static void main(String[] args) {
		
		byte byteValue =20;   //1����Ʈ
		int intValue = byteValue; //4����Ʈ
		System.out.println(intValue);
		
		
		intValue = 500;  //4����Ʈ
		long longValue = intValue; // 8����Ʈ
		
		System.out.println(longValue);
		
		/**
		 *���� Ÿ�� ��ȯ �� 
		 * 
		 */
		int intValue2 = 44035;
		char charValue = (char) intValue2;
		System.out.println(charValue);
		
		
		long longValue2 = 20000000;
		int intVal = (int) longValue2;
		
		System.out.println(intVal);
		
		
  
	}

}
