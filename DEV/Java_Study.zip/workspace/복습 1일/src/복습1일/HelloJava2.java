package ����1��;

public class HelloJava2 {

	public static void main(String[] args) {
		char c1='A';
		char c2= 65;
		char c3= 44032;
		char c4= '\u0041';
		
		System.out.println(c1);
		System.out.println(c2);
		System.out.println(c3);
		System.out.println(c4);
				
				
			
	}

}
