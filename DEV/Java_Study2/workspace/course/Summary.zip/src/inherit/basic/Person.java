package inherit.basic;

public class Person {

	 int age;
	 String name;
	 
	String info() {
		 
		 return "�̸�:" +name + " ,����:"+age;
	 }
}
