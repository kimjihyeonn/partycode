package static_basic2;

public class MainClass {

	public static void main(String[] args) {

          //static �޼����� ȣ����.
		
		Count.b++;
		Count.method02();
		
		
	  MainClass m = new MainClass();
	  
	  m.c = 1;
	  
	  System.out.println(Calculator.circle(7));
	  
		
	}
	
	int c =1;
	
	

}
