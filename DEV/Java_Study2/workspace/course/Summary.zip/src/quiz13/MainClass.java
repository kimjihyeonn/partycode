package quiz13;

public class MainClass {

	public static void main(String[] args) {
		Car mycar = new Car("���ָ�");
		
		mycar.run();
		
	}

}
