package inter.basic;

public interface Inter2 {
	
	 double pi = 3.14;
	 
	 void method02();
	 

}
