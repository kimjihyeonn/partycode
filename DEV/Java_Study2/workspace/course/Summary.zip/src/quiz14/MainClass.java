package quiz14;

public class MainClass {

	public static void main(String[] args) {

  SuperSonicAp ap = new SuperSonicAp("���ۼҴ�");
   ap.flyMode=1;
   ap.fly();

	}

}
