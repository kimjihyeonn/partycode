package overloading.basic;

public class MainClass {

	
	public static void main(String[] args) {
		Basic basic = new Basic();
		
		basic.input(9);
		basic.input("���ƾ�");
		basic.input("�ƾ�",1);
		basic.input(1,"�ƾ�");
		
		//�޼ҵ� 
		
	}
}
