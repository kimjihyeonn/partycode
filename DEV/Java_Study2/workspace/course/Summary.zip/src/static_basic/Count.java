package static_basic;

public class Count {
	
	public int a; 
	public static int b;
	
	

}
