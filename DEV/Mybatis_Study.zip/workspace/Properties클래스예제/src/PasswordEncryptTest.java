import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class PasswordEncryptTest {

	public static void main(String[] args)
	throws NoSuchAlgorithmException, UnsupportedEncodingException{
		String plainTextEx = "test1234"; //����� �н�����
		String sha256 = "";
		try {
			MessageDigest mdSHA256 = MessageDigest.getInstance("SHA-256");
			mdSHA256.update(plainTextEx.getBytes("EUC-KR"));
			
			byte[] sha256Hash = mdSHA256.digest();
			
			StringBuffer hexSHA256hash = new StringBuffer();
			
			for(byte b: sha256Hash) {
				String hexString = String.format("%02x", b); //32byte *2 = 64�ڸ�
				hexSHA256hash.append(hexString);
			}
			sha256 = hexSHA256hash.toString();
			
		}catch(NoSuchAlgorithmException e) {e.printStackTrace();}
	catch(UnsupportedEncodingException ex) {ex.printStackTrace();}
		
		System.out.println(sha256);
	 //937e8d5fbb48bd4949536cd65b8d35c426b80d2f830c5c308e2cdec422ae2244
     

		//16���� 64�ڸ�
		//1byte= 8bit
		//256bit/8 = 32byte
	}

	}


