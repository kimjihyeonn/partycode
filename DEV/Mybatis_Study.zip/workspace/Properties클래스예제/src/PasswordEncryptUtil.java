import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class PasswordEncryptUtil {
	//��ȣȭ ��Ű�� �޼ҵ屸��
	
	public static String encryptSHA256(String plainText)
	throws NoSuchAlgorithmException, UnsupportedEncodingException{
		String plainTextEx = "test1234";
		String sha256 = "";
		try {
			MessageDigest mdSHA256 = MessageDigest.getInstance("SHA-256");
			mdSHA256.update(plainTextEx.getBytes("EUC-KR"));
			
			byte[] sha256Hash = mdSHA256.digest();
			
			StringBuffer hexSHA256hash = new StringBuffer();
			
			for(byte b: sha256Hash) {
				String hexString = String.format("%02x", b);
				hexSHA256hash.append(hexString);
			}
			sha256 = hexSHA256hash.toString();
			
		}catch(NoSuchAlgorithmException e) {e.printStackTrace();}
	catch(UnsupportedEncodingException ex) {ex.printStackTrace();}
		
		System.out.println(sha256);
	 return sha256;
	}

	public static void main(String[] args) {
		PasswordEncryptUtil
	}
}


