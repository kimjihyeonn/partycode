import java.util.Enumeration;
import java.util.Properties;

public class PropertiesClassEx {

	public static void main(String[] args) {
		
		Properties pro = new Properties();
		
		//��ü�� key�� value ���� ����
		
		pro.setProperty("name", "������");
		pro.setProperty("email", "foprov@naver.com");
		pro.setProperty("HP", "010-3033-3098");
		
		//��������
		Enumeration enu = pro.propertyNames();
		
		while(enu.hasMoreElements()) {
			String ele = (String) enu.nextElement();
			System.out.println(ele + ":" + pro.getProperty(ele));
		}

	}

}
